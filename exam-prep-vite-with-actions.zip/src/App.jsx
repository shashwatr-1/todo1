import React, { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle2, Circle, Trash2, Plus, Pencil, BookOpen, BarChart3, ListTodo, Search, Filter, Clock, ChevronRight, ChevronDown, X, AlertTriangle, Link as LinkIcon, Upload, Download } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const LS_KEYS = {
  TASKS: "examtracker.tasks.v1",
  ERRORS: "examtracker.errors.v1",
};

function useLocalStorage(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : initialValue;
    } catch {
      return initialValue;
    }
  });
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch {}
  }, [key, value]);
  return [value, setValue];
}

const priorities = ["Low", "Medium", "High", "Critical"]; 

function id() {
  return Math.random().toString(36).slice(2) + Date.now().toString(36);
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function addDays(iso, days) {
  const d = iso ? new Date(iso) : new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function classNames(...a) {
  return a.filter(Boolean).join(" ");
}

export default function ExamTrackerApp() {
  const [activeTab, setActiveTab] = useState("tasks");
  const [tasks, setTasks] = useLocalStorage(LS_KEYS.TASKS, []);
  const [errors, setErrors] = useLocalStorage(LS_KEYS.ERRORS, []);

  const subjects = useMemo(() => {
    const s = new Set();
    tasks.forEach(t => t.subject && s.add(t.subject));
    errors.forEach(e => e.topic && s.add(e.topic));
    return Array.from(s);
  }, [tasks, errors]);

  // Keyboard shortcut: n = new task; / = search
  useEffect(() => {
    const onKey = (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.key === 'n') {
        document.getElementById('newTaskTitle')?.focus();
      }
      if (e.key === '/') {
        e.preventDefault();
        document.getElementById('globalSearch')?.focus();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  // Progress calculations
  const completedCount = tasks.filter(t => t.completedAt).length;
  const activeCount = tasks.length;
  const completionRate = activeCount ? Math.round((completedCount / activeCount) * 100) : 0;

  const dailyCompletions = useMemo(() => {
    // last 14 days
    const days = [];
    for (let i = 13; i >= 0; i--) {
      const d = addDays(todayISO(), -i);
      days.push({ date: d, count: 0 });
    }
    tasks.forEach(t => {
      if (t.completedAt) {
        const key = t.completedAt.slice(0, 10);
        const bucket = days.find(d => d.date === key);
        if (bucket) bucket.count += 1;
      }
    });
    return days;
  }, [tasks]);

  const streak = useMemo(() => {
    // consecutive days ending today or yesterday with at least one completion
    let s = 0;
    for (let i = 0; i < 365; i++) {
      const d = addDays(todayISO(), -i);
      const has = tasks.some(t => t.completedAt && t.completedAt.slice(0, 10) === d);
      if (i === 0 && !has) {
        // allow yesterday if today has none
        const y = addDays(todayISO(), -1);
        const hasY = tasks.some(t => t.completedAt && t.completedAt.slice(0, 10) === y);
        if (!hasY) break;
        else {
          s += 1; // yesterday
          continue;
        }
      }
      if (has) s += 1; else break;
    }
    return s;
  }, [tasks]);

  const subjectStats = useMemo(() => {
    const map = {};
    tasks.forEach(t => {
      if (t.completedAt) {
        map[t.subject || 'General'] = (map[t.subject || 'General'] || 0) + 1;
      }
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [tasks]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-slate-800 text-slate-100">
      <header className="sticky top-0 z-20 backdrop-blur supports-[backdrop-filter]:bg-slate-900/70 bg-slate-900/60 border-b border-slate-800">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-4">
          <div className="p-2 rounded-2xl bg-slate-800/60 shadow-lg">
            <BookOpen className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h1 className="text-xl sm:text-2xl font-semibold">Exam Prep — To‑Do & Error Log</h1>
            <p className="text-slate-400 text-sm">Track tasks, review mistakes, and visualize progress. (Press <kbd className="px-1 py-0.5 rounded border border-slate-700">n</kbd> for new task, <kbd className="px-1 py-0.5 rounded border border-slate-700">/</kbd> to search)</p>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <ProgressPill label="Completed" value={completedCount} />
            <ProgressPill label="Total" value={activeCount} />
            <ProgressBar percent={completionRate} />
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        <Tabs activeTab={activeTab} onChange={setActiveTab} />

        <div className="mt-6">
          <AnimatePresence mode="wait">
            {activeTab === "tasks" && (
              <motion.div key="tasks" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}>
                <TasksTab tasks={tasks} setTasks={setTasks} subjects={subjects} />
              </motion.div>
            )}
            {activeTab === "progress" && (
              <motion.div key="progress" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}>
                <ProgressTab tasks={tasks} completionRate={completionRate} streak={streak} dailyCompletions={dailyCompletions} subjectStats={subjectStats} />
              </motion.div>
            )}
            {activeTab === "errors" && (
              <motion.div key="errors" initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}>
                <ErrorsTab errors={errors} setErrors={setErrors} subjects={subjects} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function Tabs({ activeTab, onChange }) {
  const tabs = [
    { id: "tasks", label: "Tasks", icon: ListTodo },
    { id: "progress", label: "Progress", icon: BarChart3 },
    { id: "errors", label: "Error Log", icon: AlertTriangle },
  ];
  return (
    <div className="flex items-center gap-2">
      {tabs.map(t => (
        <button key={t.id} onClick={() => onChange(t.id)} className={classNames("flex items-center gap-2 px-4 py-2 rounded-2xl border transition shadow-sm", activeTab === t.id ? "bg-slate-100 text-slate-900 border-slate-200" : "bg-slate-800/70 border-slate-700 hover:bg-slate-800")}> 
          <t.icon className="w-4 h-4" />
          <span className="font-medium">{t.label}</span>
        </button>
      ))}
      <GlobalSearch />
    </div>
  );
}

function GlobalSearch() {
  const [q, setQ] = useState("");
  return (
    <div className="ml-auto relative">
      <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
      <input id="globalSearch" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Quick notes…" className="pl-9 pr-3 py-2 w-64 rounded-2xl bg-slate-800/70 border border-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500" />
    </div>
  );
}

function ProgressPill({ label, value }) {
  return (
    <div className="px-3 py-1 rounded-xl bg-slate-800/70 border border-slate-700 text-sm">
      <span className="text-slate-400 mr-2">{label}</span>
      <span className="font-semibold">{value}</span>
    </div>
  );
}

function ProgressBar({ percent }) {
  return (
    <div className="w-40">
      <div className="text-xs text-slate-400 mb-1">Completion</div>
      <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden border border-slate-700">
        <div className="h-full bg-indigo-500" style={{ width: `${percent}%` }} />
      </div>
      <div className="text-right text-xs mt-1">{percent}%</div>
    </div>
  );
}

// -------------------- TASKS TAB --------------------
function TasksTab({ tasks, setTasks, subjects }) {
  const [filter, setFilter] = useState({ q: '', subject: 'All', status: 'All', priority: 'All', due: 'All' });
  const [editing, setEditing] = useState(null);

  const filtered = useMemo(() => {
    return tasks
      .filter(t => filter.subject === 'All' || (t.subject || 'General') === filter.subject)
      .filter(t => filter.status === 'All' || (filter.status === 'Open' ? !t.completedAt : !!t.completedAt))
      .filter(t => filter.priority === 'All' || t.priority === filter.priority)
      .filter(t => {
        if (filter.due === 'Today') return (t.dueDate === todayISO());
        if (filter.due === 'Overdue') return (!!t.dueDate && t.dueDate < todayISO() && !t.completedAt);
        if (filter.due === 'This Week') {
          const now = new Date();
          const end = new Date();
          end.setDate(now.getDate() + (7 - now.getDay()));
          return !!t.dueDate && new Date(t.dueDate) <= end;
        }
        return true;
      })
      .filter(t => !filter.q || (t.title + ' ' + (t.notes||'') + ' ' + (t.subject||'')).toLowerCase().includes(filter.q.toLowerCase()))
      .sort((a,b) => (a.completedAt?1:0)-(b.completedAt?1:0) || (a.dueDate||'9999').localeCompare(b.dueDate||'9999'));
  }, [tasks, filter]);

  function addTask(data) {
    setTasks(prev => [{ id: id(), createdAt: new Date().toISOString(), completedAt: null, ...data }, ...prev]);
  }
  function toggleTask(tid) {
    setTasks(prev => prev.map(t => t.id === tid ? { ...t, completedAt: t.completedAt ? null : new Date().toISOString() } : t));
  }
  function removeTask(tid) {
    setTasks(prev => prev.filter(t => t.id !== tid));
  }
  function saveTask(tid, patch) {
    setTasks(prev => prev.map(t => t.id === tid ? { ...t, ...patch } : t));
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-4 min-w-0">
        <TaskComposer onAdd={addTask} subjects={subjects} />

        <div className="flex flex-wrap items-center gap-2 p-3 rounded-2xl bg-slate-800/60 border border-slate-700">
          <Filter className="w-4 h-4 text-slate-400" />
          <input value={filter.q} onChange={e=>setFilter(f=>({...f,q:e.target.value}))} placeholder="Search tasks…" className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
          <Select value={filter.subject} onChange={v=>setFilter(f=>({...f,subject:v}))} options={["All", ...new Set(["General", ...subjects])]} />
          <Select value={filter.status} onChange={v=>setFilter(f=>({...f,status:v}))} options={["All","Open","Done"]} />
          <Select value={filter.priority} onChange={v=>setFilter(f=>({...f,priority:v}))} options={["All",...priorities]} />
          <Select value={filter.due} onChange={v=>setFilter(f=>({...f,due:v}))} options={["All","Today","This Week","Overdue"]} />
        </div>

        <div className="space-y-2">
          {filtered.map(t => (
            <motion.div layout key={t.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className={classNames("p-4 rounded-2xl border shadow-sm", t.completedAt ? "bg-emerald-900/20 border-emerald-800" : "bg-slate-800/60 border-slate-700")}> 
              <div className="flex items-start gap-3">
                <button onClick={()=>toggleTask(t.id)} className="mt-0.5">
                  {t.completedAt ? <CheckCircle2 className="w-6 h-6 text-emerald-400"/> : <Circle className="w-6 h-6 text-slate-400"/>}
                </button>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className={classNames("font-semibold", t.completedAt && "line-through text-slate-400")}>{t.title}</h3>
                    <Badge>{t.subject || 'General'}</Badge>
                    <Badge tone={t.priority === 'Critical' ? 'red' : t.priority === 'High' ? 'amber' : t.priority === 'Medium' ? 'blue' : 'slate'}>{t.priority || 'Medium'}</Badge>
                    {t.dueDate && <span className={classNames("text-xs px-2 py-1 rounded-full border", (!t.completedAt && t.dueDate < todayISO()) ? "border-red-500 text-red-300" : "border-slate-600 text-slate-300")}>Due {t.dueDate}</span>}
                  </div>
                  {t.notes && <p className="text-slate-300 mt-1 whitespace-pre-wrap">{t.notes}</p>}
                  <div className="text-xs text-slate-400 mt-2 flex flex-wrap gap-3">
                    <span><Clock className="w-3 h-3 inline -mt-0.5 mr-1"/>Created {new Date(t.createdAt).toLocaleString()}</span>
                    {t.completedAt && <span>✓ Completed {new Date(t.completedAt).toLocaleString()}</span>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <IconButton onClick={()=>setEditing(t)} icon={Pencil} label="Edit" />
                  <IconButton onClick={()=>removeTask(t.id)} icon={Trash2} label="Delete" />
                </div>
              </div>
            </motion.div>
          ))}
          {filtered.length === 0 && (
            <EmptyState title="No tasks match." subtitle="Try changing filters or add a new task." />
          )}
        </div>
      </div>

      <aside className="space-y-4">
        <Card title="At a glance">
          <div className="grid grid-cols-3 gap-3">
            <Stat label="Total" value={tasks.length} />
            <Stat label="Done" value={tasks.filter(t=>t.completedAt).length} />
            <Stat label="Open" value={tasks.filter(t=>!t.completedAt).length} />
          </div>
        </Card>
        <Card title="Tips">
          <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
            <li>Use priorities to highlight what truly matters.</li>
            <li>Break large tasks into smaller subtasks for momentum.</li>
            <li>Mark tasks done as soon as you complete them to update analytics.</li>
          </ul>
        </Card>
      </aside>

      <EditTaskDialog open={!!editing} onClose={()=>setEditing(null)} task={editing} onSave={(patch)=>{ if(editing) { setTasks(prev=>prev.map(t=>t.id===editing.id?{...t,...patch}:t)); setEditing(null);} }} />
    </div>
  );
}

function TaskComposer({ onAdd, subjects }) {
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [priority, setPriority] = useState("Medium");
  const [notes, setNotes] = useState("");
  const inputRef = useRef(null);

  function submit(e) {
    e.preventDefault();
    if (!title.trim()) return;
    onAdd({ title: title.trim(), subject: subject.trim(), dueDate: dueDate || null, priority, notes: notes.trim() });
    setTitle(""); setSubject(""); setDueDate(""); setPriority("Medium"); setNotes("");
    inputRef.current?.focus();
  }

  return (
    <form onSubmit={submit} className="p-4 rounded-2xl border bg-slate-800/60 border-slate-700 shadow-sm">
      <div className="flex flex-col md:flex-row md:flex-wrap gap-3">
        <input id="newTaskTitle" ref={inputRef} value={title} onChange={e=>setTitle(e.target.value)} placeholder="Add a task (e.g., " aria-label="Task title" className="flex-1 min-w-0 px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
        <input value={subject} onChange={e=>setSubject(e.target.value)} placeholder="Subject/Topic" className="w-full md:w-40 min-w-[10rem] px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
        <input type="date" value={dueDate||''} onChange={e=>setDueDate(e.target.value)} className="w-full md:w-40 min-w-[10rem] px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
        <Select value={priority} onChange={setPriority} options={priorities} />
        <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white font-medium flex items-center gap-2 shadow shrink-0">
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>
      <textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Notes (optional)" className="mt-3 w-full px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" rows={2} />
    </form>
  );
}

function EditTaskDialog({ open, onClose, task, onSave }) {
  const [state, setState] = useState(task || {});
  useEffect(()=>{ setState(task||{}); }, [task]);
  if (!open || !task) return null;
  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/60" onClick={onClose} />
      <div className="relative z-10 w-full max-w-lg p-4">
        <div className="rounded-2xl bg-slate-900 border border-slate-700 p-4 shadow-xl">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Edit Task</h3>
            <button onClick={onClose} className="p-1 rounded hover:bg-slate-800"><X className="w-5 h-5"/></button>
          </div>
          <div className="mt-3 space-y-3">
            <LabeledInput label="Title" value={state.title||''} onChange={v=>setState(s=>({...s,title:v}))} />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <LabeledInput label="Subject" value={state.subject||''} onChange={v=>setState(s=>({...s,subject:v}))} />
              <LabeledInput label="Due Date" type="date" value={state.dueDate||''} onChange={v=>setState(s=>({...s,dueDate:v}))} />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <LabeledSelect label="Priority" value={state.priority||'Medium'} onChange={v=>setState(s=>({...s,priority:v}))} options={priorities} />
              <LabeledSelect label="Status" value={state.completedAt? 'Done' : 'Open'} onChange={v=>setState(s=>({...s,completedAt: v==='Done'? new Date().toISOString(): null}))} options={["Open","Done"]} />
            </div>
            <LabeledTextarea label="Notes" value={state.notes||''} onChange={v=>setState(s=>({...s,notes:v}))} rows={3} />
          </div>
          <div className="mt-4 flex justify-end gap-2">
            <button onClick={onClose} className="px-4 py-2 rounded-xl border border-slate-700">Cancel</button>
            <button onClick={()=>onSave(state)} className="px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white font-medium">Save</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// -------------------- PROGRESS TAB --------------------
function ProgressTab({ tasks, completionRate, streak, dailyCompletions, subjectStats }) {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-4">
        <Card title="Daily Completions (Last 14 days)">
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={dailyCompletions}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" tick={{ fontSize: 12 }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12 }} />
                <Tooltip />
                <Line type="monotone" dataKey="count" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card title="Completions by Subject">
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie dataKey="value" data={subjectStats} nameKey="name" outerRadius={90} label>
                  {subjectStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <aside className="space-y-4">
        <Card title="Summary">
          <div className="grid grid-cols-2 gap-3">
            <Stat label="Tasks" value={tasks.length} />
            <Stat label="Completion" value={`${completionRate}%`} />
            <Stat label="Streak" value={`${streak} days`} />
            <Stat label="Done" value={tasks.filter(t=>t.completedAt).length} />
          </div>
        </Card>
        <Card title="Suggestions">
          <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
            <li>Aim to complete at least one task daily to keep the streak alive.</li>
            <li>Balance subjects—watch the pie chart for neglected topics.</li>
            <li>Use the Error Log to convert mistakes into new tasks.</li>
          </ul>
        </Card>
      </aside>
    </div>
  );
}

// -------------------- ERRORS TAB --------------------
function ErrorsTab({ errors, setErrors, subjects }) {
  const [filter, setFilter] = useState({ q: '', topic: 'All', status: 'All', due: 'All' });

  const filtered = useMemo(() => {
    return errors
      .filter(e => filter.topic === 'All' || (e.topic || 'General') === filter.topic)
      .filter(e => filter.status === 'All' || (filter.status === 'Open' ? e.status !== 'resolved' : e.status === 'resolved'))
      .filter(e => {
        if (filter.due === 'Today') return (e.nextReviewDate === todayISO());
        if (filter.due === 'Overdue') return (!!e.nextReviewDate && e.nextReviewDate < todayISO() && e.status !== 'resolved');
        return true;
      })
      .filter(e => !filter.q || (e.question + ' ' + (e.notes||'') + ' ' + (e.topic||'') + ' ' + (e.tags||[]).join(' ')).toLowerCase().includes(filter.q.toLowerCase()))
      .sort((a,b) => (a.status === 'resolved') - (b.status === 'resolved') || (a.nextReviewDate||'9999').localeCompare(b.nextReviewDate||'9999'));
  }, [errors, filter]);

  function addError(data) {
    setErrors(prev => [{ id: id(), addedAt: new Date().toISOString(), status: 'open', timesReviewed: 0, nextReviewDate: addDays(todayISO(), 1), ...data }, ...prev]);
  }
  function updateError(eid, patch) {
    setErrors(prev => prev.map(e => e.id === eid ? { ...e, ...patch } : e));
  }
  function removeError(eid) {
    setErrors(prev => prev.filter(e => e.id !== eid));
  }

  function quickReview(e, days) {
    updateError(e.id, { timesReviewed: (e.timesReviewed||0) + 1, nextReviewDate: addDays(todayISO(), days) });
  }

  function exportJSON() {
    const blob = new Blob([JSON.stringify(errors, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `error-log-${todayISO()}.json`; a.click();
    URL.revokeObjectURL(url);
  }

  function importJSON(ev) {
    const file = ev.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (Array.isArray(data)) setErrors(data);
      } catch {}
    };
    reader.readAsText(file);
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-4">
        <ErrorComposer onAdd={addError} subjects={subjects} />

        <div className="flex flex-wrap items-center gap-2 p-3 rounded-2xl bg-slate-800/60 border border-slate-700">
          <Filter className="w-4 h-4 text-slate-400" />
          <input value={filter.q} onChange={e=>setFilter(f=>({...f,q:e.target.value}))} placeholder="Search errors…" className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
          <Select value={filter.topic} onChange={v=>setFilter(f=>({...f,topic:v}))} options={["All", ...new Set(["General", ...subjects])]} />
          <Select value={filter.status} onChange={v=>setFilter(f=>({...f,status:v}))} options={["All","Open","Resolved"]} />
          <Select value={filter.due} onChange={v=>setFilter(f=>({...f,due:v}))} options={["All","Today","Overdue"]} />
          <div className="ml-auto flex items-center gap-2">
            <button onClick={exportJSON} className="px-3 py-2 rounded-xl border border-slate-700 flex items-center gap-2"><Download className="w-4 h-4"/>Export</button>
            <label className="px-3 py-2 rounded-xl border border-slate-700 flex items-center gap-2 cursor-pointer">
              <Upload className="w-4 h-4"/> Import
              <input type="file" accept="application/json" className="hidden" onChange={importJSON} />
            </label>
          </div>
        </div>

        <div className="space-y-2">
          {filtered.map(e => (
            <motion.div layout key={e.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className={classNames("p-4 rounded-2xl border shadow-sm", e.status === 'resolved' ? "bg-emerald-900/20 border-emerald-800" : "bg-slate-800/60 border-slate-700")}> 
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  {e.status === 'resolved' ? <CheckCircle2 className="w-6 h-6 text-emerald-400"/> : <AlertTriangle className="w-6 h-6 text-amber-400"/>}
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-semibold">{e.question}</h3>
                    <Badge>{e.topic || 'General'}</Badge>
                    {(e.tags||[]).map(t => <Badge key={t} tone="slate">#{t}</Badge>)}
                    {e.nextReviewDate && <span className={classNames("text-xs px-2 py-1 rounded-full border", (e.status !== 'resolved' && e.nextReviewDate < todayISO()) ? "border-red-500 text-red-300" : "border-slate-600 text-slate-300")}>Review {e.nextReviewDate}</span>}
                  </div>
                  {e.notes && <p className="text-slate-300 mt-1 whitespace-pre-wrap">{e.notes}</p>}
                  <div className="text-xs text-slate-400 mt-2 flex flex-wrap gap-3">
                    <span><Clock className="w-3 h-3 inline -mt-0.5 mr-1"/>Added {new Date(e.addedAt).toLocaleString()}</span>
                    <span>Reviews: {e.timesReviewed||0}</span>
                    {e.source && <span>Source: {e.source}</span>}
                    {e.link && <a href={e.link} target="_blank" rel="noreferrer" className="underline inline-flex items-center gap-1"><LinkIcon className="w-3 h-3"/>Link</a>}
                  </div>
                </div>
                <div className="flex flex-col gap-2 items-end">
                  <div className="flex items-center gap-2">
                    <IconButton onClick={()=>updateError(e.id, { status: e.status === 'resolved' ? 'open' : 'resolved' })} icon={e.status==='resolved'?Circle:CheckCircle2} label={e.status==='resolved'?'Reopen':'Resolve'} />
                    <IconButton onClick={()=>removeError(e.id)} icon={Trash2} label="Delete" />
                  </div>
                  {e.status !== 'resolved' && (
                    <div className="flex items-center gap-2 text-xs">
                      <span className="text-slate-400">Next review:</span>
                      <QuickChip onClick={()=>quickReview(e,1)}>1d</QuickChip>
                      <QuickChip onClick={()=>quickReview(e,3)}>3d</QuickChip>
                      <QuickChip onClick={()=>quickReview(e,7)}>7d</QuickChip>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
          {filtered.length === 0 && (
            <EmptyState title="Nothing here yet." subtitle="Add questions you struggled with and schedule reviews." />
          )}
        </div>
      </div>

      <aside className="space-y-4">
        <Card title="Review Queue">
          <div className="space-y-2">
            {errors.filter(e=>e.status!=='resolved').filter(e=>e.nextReviewDate && e.nextReviewDate <= todayISO()).slice(0,8).map(e => (
              <div key={e.id} className="p-3 rounded-xl bg-slate-900/60 border border-slate-700">
                <div className="text-sm font-medium">{e.question}</div>
                <div className="text-xs text-slate-400">Due {e.nextReviewDate}</div>
              </div>
            ))}
            {errors.filter(e=>e.status!=='resolved' && e.nextReviewDate && e.nextReviewDate <= todayISO()).length === 0 && (
              <div className="text-sm text-slate-400">No due reviews. Nice!</div>
            )}
          </div>
        </Card>
        <Card title="How to use">
          <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
            <li>Log unsolved questions with topic, tags, and notes.</li>
            <li>Use quick chips (1d/3d/7d) for spaced reviews.</li>
            <li>Resolve once you can solve similar problems confidently.</li>
          </ul>
        </Card>
      </aside>
    </div>
  );
}

function ErrorComposer({ onAdd, subjects }) {
  const [question, setQuestion] = useState("");
  const [topic, setTopic] = useState("");
  const [tags, setTags] = useState("");
  const [source, setSource] = useState("");
  const [link, setLink] = useState("");
  const [notes, setNotes] = useState("");

  function submit(e) {
    e.preventDefault();
    if (!question.trim()) return;
    onAdd({ question: question.trim(), topic: topic.trim(), tags: tags.split(',').map(s=>s.trim()).filter(Boolean), source: source.trim(), link: link.trim(), notes: notes.trim() });
    setQuestion(""); setTopic(""); setTags(""); setSource(""); setLink(""); setNotes("");
  }

  return (
    <form onSubmit={submit} className="p-4 rounded-2xl border bg-slate-800/60 border-slate-700 shadow-sm">
      <div className="flex flex-col gap-3">
        <input value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Enter the question or a short summary you couldn't solve" className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <input value={topic} onChange={e=>setTopic(e.target.value)} placeholder="Topic/Subject" className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
          <input value={tags} onChange={e=>setTags(e.target.value)} placeholder="Tags (comma separated)" className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input value={source} onChange={e=>setSource(e.target.value)} placeholder="Source (book/test)" className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
          <input value={link} onChange={e=>setLink(e.target.value)} placeholder="Reference link (optional)" className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" />
          <input type="date" value={addDays(null,1)} readOnly className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 text-slate-400" />
        </div>
        <textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="Why was it hard? What will you do next time?" className="w-full px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none" rows={3} />
        <div className="flex justify-end">
          <button type="submit" className="px-4 py-2 rounded-xl bg-indigo-500 hover:bg-indigo-600 text-white font-medium flex items-center gap-2">
            <Plus className="w-4 h-4"/> Add to Error Log
          </button>
        </div>
      </div>
    </form>
  );
}

// -------------------- UI PRIMITIVES --------------------
function Card({ title, children }) {
  const [open, setOpen] = useState(true);
  return (
    <div className="rounded-2xl bg-slate-800/60 border border-slate-700 shadow-sm">
      <button onClick={()=>setOpen(o=>!o)} className="w-full flex items-center justify-between px-4 py-3">
        <div className="font-semibold">{title}</div>
        {open ? <ChevronDown className="w-4 h-4"/> : <ChevronRight className="w-4 h-4"/>}
      </button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="px-4 pb-4">
            {children}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-700 text-center">
      <div className="text-xs text-slate-400">{label}</div>
      <div className="text-lg font-semibold">{value}</div>
    </div>
  );
}

function Badge({ children, tone = 'indigo' }) {
  const toneMap = {
    indigo: 'text-indigo-300 border-indigo-500/40',
    red: 'text-red-300 border-red-500/40',
    amber: 'text-amber-300 border-amber-500/40',
    blue: 'text-blue-300 border-blue-500/40',
    slate: 'text-slate-300 border-slate-600',
  };
  return (
    <span className={classNames('text-xs px-2 py-0.5 rounded-full border', toneMap[tone] || toneMap.indigo)}>{children}</span>
  );
}

function IconButton({ onClick, icon: Icon, label }) {
  return (
    <button onClick={onClick} className="p-2 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-200" title={label} aria-label={label}>
      <Icon className="w-4 h-4" />
    </button>
  );
}

function Select({ value, onChange, options }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const onDoc = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener('click', onDoc);
    return () => document.removeEventListener('click', onDoc);
  }, []);
  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={()=>setOpen(o=>!o)} className="px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 min-w-[8rem] flex items-center justify-between gap-2">
        <span className="truncate">{value}</span>
        <ChevronDown className="w-4 h-4 text-slate-400" />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }} className="absolute z-10 mt-2 w-full rounded-xl border border-slate-700 bg-slate-900 shadow-lg max-h-64 overflow-auto">
            {options.map(opt => (
              <button key={opt} onClick={()=>{ onChange(opt); setOpen(false); }} className={classNames("w-full text-left px-3 py-2 hover:bg-slate-800", opt === value && "bg-slate-800/70")}>{opt}</button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function LabeledInput({ label, ...props }) {
  return (
    <label className="block">
      <div className="text-xs text-slate-400 mb-1">{label}</div>
      <input {...props} className={classNames("w-full px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none", props.className)} />
    </label>
  );
}
function LabeledTextarea({ label, rows=3, ...props }) {
  return (
    <label className="block">
      <div className="text-xs text-slate-400 mb-1">{label}</div>
      <textarea {...props} rows={rows} className={classNames("w-full px-3 py-2 rounded-xl bg-slate-900/60 border border-slate-700 focus:outline-none", props.className)} />
    </label>
  );
}
function LabeledSelect({ label, value, onChange, options }) {
  return (
    <label className="block">
      <div className="text-xs text-slate-400 mb-1">{label}</div>
      <Select value={value} onChange={onChange} options={options} />
    </label>
  );
}

function QuickChip({ children, onClick }) {
  return (
    <button onClick={onClick} className="px-2 py-1 text-xs rounded-lg border border-slate-700 hover:bg-slate-800">{children}</button>
  );
}

function EmptyState({ title, subtitle }) {
  return (
    <div className="p-6 rounded-2xl border border-slate-700 text-center text-slate-300 bg-slate-800/40">
      <div className="text-sm font-medium">{title}</div>
      <div className="text-xs text-slate-400">{subtitle}</div>
    </div>
  );
}
